
import React from 'react';
import { Link } from 'react-router-dom';

const Dashboard = () => {
    return (
      <>
        <header>
          <h1>Admin Dashboard</h1>
          <nav>
            <a href="menu-management.html">Menu Management</a>
            <a href="order-management.html">Order Management</a>
            <a href="staff-management.html">Staff Management</a>
            <a href="reports.html">Reports</a>
            <a href="settings.html">Settings</a>
          </nav>
        </header>
        <main>
          <section>
            <h2>Overview</h2>
            <ul>
              <li>Total Orders: 120</li>
              <li>Revenue: $5000</li>
              <li>Feedback Rating: 4.5/5</li>
            </ul>
          </section>
        </main>
      </>
    );
};

export default Dashboard;

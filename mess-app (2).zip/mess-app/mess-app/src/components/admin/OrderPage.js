import React from 'react'

function OrderPage() {
  return (
    <div>OrderPage</div>
  )
}

export default OrderPage
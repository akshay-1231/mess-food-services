import React, { useState } from 'react';

const Menu = () => {
  // Sample data for menu items
  const menuData = {
    breakfast: [
      { name: "Pancakes", image: "./src/assets/pancake.jpg", description: "Fluffy pancakes with syrup.", price: "$5" },
      { name: "Eggs & Toast", image: "./src/assets/egges.jpg", description: "Scrambled eggs with buttered toast.", price: "$4" }
    ],
    lunch: [
      { name: "Grilled Chicken", image: "./src/assets/cchiken.jpg", description: "Tender grilled chicken with salad.", price: "$8" },
      { name: "Veg Burger", image: "./src/assets/veg burger.jpg", description: "A healthy vegetarian burger.", price: "$6" }
    ],
    dinner: [
      { name: "Pasta", image: "./src/assets/pasta.jpg", description: "Creamy pasta with garlic bread.", price: "$7" },
      { name: "Fish Curry", image: "./src/assets/fishcurry.jpg", description: "Spicy fish curry with rice.", price: "$9" }
    ],
    snacks: [
      { name: "Samosa", image: "./src/assets/samaosa.jpg", description: "Crunchy samosas filled with potatoes.", price: "$2" },
      { name: "Chips", image: "./src/assets/chips.jpg", description: "Crispy potato chips.", price: "$1.5" }
    ]
  };

  // State to hold the selected menu and the loading state
  const [selectedMenu, setSelectedMenu] = useState('');
  const [loading, setLoading] = useState(false);
  const [menuItems, setMenuItems] = useState([]);

  // Handle menu category change
  const handleMenuChange = (event) => {
    setSelectedMenu(event.target.value);
    setLoading(true);
    setMenuItems([]);

    // Simulate a delay for loading the menu
    setTimeout(() => {
      if (menuData[event.target.value]) {
        setMenuItems(menuData[event.target.value]);
      }
      setLoading(false);
    }, 500);
  };

  return (
    <div className="container mt-5">
      <h1 className="text-center mb-4">Welcome to Our Mess</h1>

      {/* Dropdown for selecting menu category */}
      <div className="row">
        <div className="col-md-6 mx-auto">
          <label htmlFor="menuSelection" className="form-label">Select Menu Category</label>
          <select id="menuSelection" className="form-select" onChange={handleMenuChange}>
            <option value="">Choose a category</option>
            <option value="breakfast">Breakfast</option>
            <option value="lunch">Lunch</option>
            <option value="dinner">Dinner</option>
            <option value="snacks">Snacks</option>
          </select>
        </div>
      </div>

      {/* Loading Spinner */}
      {loading && (
        <div id="loadingSpinner" className="text-center my-4">
          <div className="spinner-border text-primary" role="status">
            <span className="visually-hidden">Loading...</span>
          </div>
        </div>
      )}

      {/* Menu Cards Section */}
      <div id="menuCards" className="card-container">
        {!loading && menuItems.length > 0 && menuItems.map(item => (
          <div className="card shadow-sm" key={item.name}>
            <img src={item.image} alt={item.name} className="card-img-top" />
            <div className="card-body">
              <h5 className="card-title">{item.name}</h5>
              <p className="card-text">{item.description}</p>
              <p className="text-muted">{item.price}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Menu;

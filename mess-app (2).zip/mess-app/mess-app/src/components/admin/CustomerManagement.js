import React from 'react'

function CustomerManagement() {
  return (
    <div>CustomerManagement</div>
  )
}

export default CustomerManagement